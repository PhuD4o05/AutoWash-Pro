package com.carwash.carwashsystem.service.impl;

import com.carwash.carwashsystem.dto.request.BookingRequest;
import com.carwash.carwashsystem.dto.response.BookingResponse;
import com.carwash.carwashsystem.entity.Booking;
import com.carwash.carwashsystem.entity.Customer;
import com.carwash.carwashsystem.entity.ServicePackage;
import com.carwash.carwashsystem.entity.Vehicle;
import com.carwash.carwashsystem.enums.BookingStatus;
import com.carwash.carwashsystem.exception.BookingConflictException;
import com.carwash.carwashsystem.exception.ResourceNotFoundException;
import com.carwash.carwashsystem.repository.BookingRepository;
import com.carwash.carwashsystem.repository.CustomerRepository;
import com.carwash.carwashsystem.repository.ServicePackageRepository;
import com.carwash.carwashsystem.repository.VehicleRepository;
import com.carwash.carwashsystem.service.interfaces.BookingService;
import com.carwash.carwashsystem.service.interfaces.EmailService;
import com.carwash.carwashsystem.service.interfaces.PricingService;
import com.carwash.carwashsystem.service.interfaces.QRCodeService;
import org.springframework.beans.factory.annotation.Value;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;
    private final CustomerRepository customerRepository;
    private final VehicleRepository vehicleRepository;
    private final ServicePackageRepository packageRepository;
    private final PricingService pricingService;
    private final QRCodeService qrCodeService;
    private final EmailService emailService;

    @Value("${app.base-url:http://localhost:8080}")
    private String baseUrl;

    @Override
    @Transactional
    public BookingResponse createBooking(BookingRequest request, Long customerId) {
        System.out.println(">>> Entered createBooking with customerId: " + customerId);
        try {
            // 1. Lấy customer
            Customer customer = customerRepository.findById(customerId)
                    .orElseThrow(() -> new ResourceNotFoundException("Customer not found with id: " + customerId));

            // 2. Lấy vehicle
            Vehicle vehicle = vehicleRepository.findById(request.getVehicleId())
                    .orElseThrow(() -> new ResourceNotFoundException("Vehicle not found with id: " + request.getVehicleId()));

            // 3. Lấy service package
            ServicePackage servicePackage = packageRepository.findById(request.getPackageId())
                    .orElseThrow(() -> new ResourceNotFoundException("Service package not found with id: " + request.getPackageId()));

            // 4. Kiểm tra slot
            if (!checkSlotAvailable(request.getScheduledTime(), request.getPackageId())) {
                throw new BookingConflictException("Time slot not available for package " + request.getPackageId() + " at " + request.getScheduledTime());
            }

            // 5. Tính giá (có bắt lỗi)
            Double finalPrice;
            try {
                finalPrice = pricingService.calculateFinalPrice(
                        request.getPackageId(),
                        request.getScheduledTime(),
                        customer.getMembershipTier().name(),
                        null
                );
                System.out.println(">>> PricingService returned: " + finalPrice);
            } catch (Exception e) {
                System.err.println(" ERROR in PricingService: " + e.getMessage());
                e.printStackTrace();
                throw new RuntimeException("Pricing calculation failed: " + e.getMessage(), e);
            }

            // 6. Tạo QR code (có bắt lỗi)
            String qrCode;
            try {
                qrCode = qrCodeService.generateQRCodeForBooking(UUID.randomUUID().toString());
                System.out.println(">>> QRCodeService generated: " + qrCode);
            } catch (Exception e) {
                System.err.println(" ERROR in QRCodeService: " + e.getMessage());
                e.printStackTrace();
                throw new RuntimeException("QR code generation failed: " + e.getMessage(), e);
            }

            // 7. Xây dựng booking entity
            Booking booking = Booking.builder()
                    .customer(customer)
                    .vehicle(vehicle)
                    .servicePackage(servicePackage)
                    .scheduledTime(request.getScheduledTime())
                    .status(BookingStatus.PENDING)
                    .totalPrice(finalPrice != null ? finalPrice : 0.0)
                    .qrCode(qrCode)
                    .build();

            // 8. Lưu
            Booking saved = bookingRepository.save(booking);
            System.out.println(">>> Booking saved with id: " + saved.getId());
            return mapToResponse(saved);

        } catch (Exception e) {
            System.err.println(" UNEXPECTED ERROR in createBooking: " + e.getMessage());
            e.printStackTrace();
            throw e; // Ném lại để controller hoặc global handler xử lý
        }
    }

    @Override
    @Transactional
    public void cancelBooking(Long bookingId, Long customerId) {
        System.out.println(">>> cancelBooking called for bookingId: " + bookingId + ", customerId: " + customerId);
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with id: " + bookingId));
        if (!booking.getCustomer().getId().equals(customerId)) {
            throw new RuntimeException("Not authorized to cancel this booking");
        }
        if (booking.getStatus() == BookingStatus.COMPLETED || booking.getStatus() == BookingStatus.CANCELLED) {
            throw new RuntimeException("Cannot cancel booking with status: " + booking.getStatus());
        }
        booking.setStatus(BookingStatus.CANCELLED);
        bookingRepository.save(booking);
        System.out.println(">>> Booking " + bookingId + " cancelled");
    }

    @Override
    @Transactional
    public BookingResponse rescheduleBooking(Long bookingId, LocalDateTime newTime, Long customerId) {
        System.out.println(">>> rescheduleBooking called for bookingId: " + bookingId + ", newTime: " + newTime);
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with id: " + bookingId));
        if (!booking.getCustomer().getId().equals(customerId)) {
            throw new RuntimeException("Not authorized to reschedule this booking");
        }
        if (!checkSlotAvailable(newTime, booking.getServicePackage().getId())) {
            throw new BookingConflictException("New time slot not available");
        }
        booking.setScheduledTime(newTime);
        booking.setStatus(BookingStatus.PENDING);
        Booking updated = bookingRepository.save(booking);
        return mapToResponse(updated);
    }

    @Override
    public BookingResponse getBookingById(Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with id: " + bookingId));
        return mapToResponse(booking);
    }

    @Override
    public List<BookingResponse> getBookingsByCustomer(Long customerId) {
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with id: " + customerId));
        return bookingRepository.findByCustomer(customer).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public BookingResponse updateBookingStatus(Long bookingId, BookingStatus status, Long actorId) {
        System.out.println(">>> updateBookingStatus called for bookingId: " + bookingId + ", new status: " + status);
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with id: " + bookingId));
        booking.setStatus(status);
        Booking updated = bookingRepository.save(booking);
        return mapToResponse(updated);
    }

    @Override
    public boolean checkSlotAvailable(LocalDateTime scheduledTime, Long servicePackageId) {
        long count = bookingRepository.countActiveBookingsInPeriod(
                scheduledTime.minusMinutes(30),
                scheduledTime.plusMinutes(30)
        );
        // Tạm cho phép tối đa 100 booking (luôn true, để tránh lỗi)
        return count < 100;
    }

    @Override
    public List<LocalDateTime> getAvailableSlots(LocalDateTime date, Long servicePackageId) {
        // TODO: implement later
        return List.of();
    }

    @Override
    public List<BookingResponse> getTodayBookings() {
        LocalDateTime start = LocalDateTime.now().withHour(0).withMinute(0);
        LocalDateTime end = start.plusDays(1);
        return bookingRepository.findByScheduledTimeBetween(start, end).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    private BookingResponse mapToResponse(Booking booking) {
        return BookingResponse.builder()
                .id(booking.getId())
                .customerId(booking.getCustomer() != null ? booking.getCustomer().getId() : null)
                .vehicleId(booking.getVehicle() != null ? booking.getVehicle().getId() : null)
                .packageId(booking.getServicePackage() != null ? booking.getServicePackage().getId() : null)
                .scheduledTime(booking.getScheduledTime())
                .status(booking.getStatus())
                .totalPrice(booking.getTotalPrice())
                .qrCode(booking.getQrCode())
                .build();
    }
}