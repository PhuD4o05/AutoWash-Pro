package com.carwash.carwashsystem.service.impl;

import com.carwash.carwashsystem.dto.request.PaymentRequest;
import com.carwash.carwashsystem.dto.response.PaymentResponse;
import com.carwash.carwashsystem.entity.Booking;
import com.carwash.carwashsystem.entity.Payment;
import com.carwash.carwashsystem.enums.BookingStatus;
import com.carwash.carwashsystem.enums.PaymentMethod;
import com.carwash.carwashsystem.enums.PaymentStatus;
import com.carwash.carwashsystem.exception.ResourceNotFoundException;
import com.carwash.carwashsystem.integration.PayosClient;
import com.carwash.carwashsystem.repository.BookingRepository;
import com.carwash.carwashsystem.repository.PaymentRepository;
import com.carwash.carwashsystem.service.interfaces.PaymentService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import vn.payos.model.v2.paymentRequests.CreatePaymentLinkResponse;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepository paymentRepository;
    private final BookingRepository bookingRepository;
    private final PayosClient payosClient;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    @Transactional
    public PaymentResponse processPayment(Long bookingId, PaymentRequest request) {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));

        if (request.getPaymentMethod() == PaymentMethod.VIETQR) {
            try {
                CreatePaymentLinkResponse payosResponse = payosClient.createPaymentLink(
                        bookingId,
                        booking.getTotalPrice().longValue(),
                        "Thanh toan booking " + bookingId
                );
                Payment payment = Payment.builder()
                        .booking(booking)
                        .amount(booking.getTotalPrice().longValue())
                        .method(PaymentMethod.VIETQR)
                        .status(PaymentStatus.PENDING)
                        .transactionId(String.valueOf(payosResponse.getOrderCode()))
                        .build();
                paymentRepository.save(payment);

                return PaymentResponse.builder()
                        .id(payment.getId())
                        .bookingId(bookingId)
                        .amount(payment.getAmount())
                        .status(PaymentStatus.PENDING)
                        .transactionId(payment.getTransactionId())
                        .checkoutUrl(payosResponse.getCheckoutUrl())  // ✅ thêm trường này
                        .build();
            } catch (Exception e) {
                throw new RuntimeException("Lỗi tạo link thanh toán: " + e.getMessage());
            }
        }

        // Các phương thức khác (CASH, PAYOS, ...)
        Long amountValue = request.getAmount() != null ? request.getAmount().longValue() : booking.getTotalPrice().longValue();
        Payment payment = Payment.builder()
                .booking(booking)
                .amount(amountValue)
                .method(request.getPaymentMethod())
                .status(PaymentStatus.PAID)
                .paidAt(LocalDateTime.now())
                .build();
        paymentRepository.save(payment);
        return PaymentResponse.builder()
                .id(payment.getId())
                .bookingId(bookingId)
                .amount(payment.getAmount())
                .status(PaymentStatus.PAID)
                .paidAt(payment.getPaidAt())
                .build();
    }

    @Override
    @Transactional
    public void handlePaymentWebhook(String webhookBody) throws Exception {
        // Xác minh chữ ký
        payosClient.verifyWebhook(webhookBody);

        JsonNode json = objectMapper.readTree(webhookBody);
        String status = json.get("data").get("status").asText();
        Long bookingId = json.get("data").get("orderCode").asLong();

        if ("PAID".equals(status)) {
            Payment payment = paymentRepository.findByTransactionId(String.valueOf(bookingId))
                    .orElseThrow(() -> new ResourceNotFoundException("Payment not found"));
            if (payment.getStatus() != PaymentStatus.PAID) {
                payment.setStatus(PaymentStatus.PAID);
                payment.setPaidAt(LocalDateTime.now());
                paymentRepository.save(payment);
                Booking booking = payment.getBooking();
                booking.setStatus(BookingStatus.CONFIRMED);
                bookingRepository.save(booking);
                log.info("Booking {} confirmed after payment", bookingId);
            }
        }
    }

    @Override
    public PaymentResponse confirmCashPayment(Long bookingId, Long receptionistId) {
        throw new UnsupportedOperationException("Chưa implement");
    }

    @Override
    public PaymentResponse getPaymentByBooking(Long bookingId) {
        throw new UnsupportedOperationException("Chưa implement");
    }

    @Override
    public PaymentResponse refundPayment(Long paymentId) {
        throw new UnsupportedOperationException("Chưa implement");
    }

    @Override
    public String createOnlinePaymentLink(Long bookingId) throws Exception {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found"));
        CreatePaymentLinkResponse response = payosClient.createPaymentLink(
                bookingId,
                booking.getTotalPrice().longValue(),
                "Thanh toan booking " + bookingId
        );
        return response.getCheckoutUrl();
    }
}